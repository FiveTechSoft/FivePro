// Data.c      (C) Antonio Linares & Francisco Pulp�n 1992

#include "extend.h"

extern quant  _lbase;
extern quant  _eval;
extern quant  _pcount;

extern void far _cAtPut( quant , quant , quant );
extern void far _cAt( quant , quant , quant, quant );

static void _SetGet( quant index )
{
  if( _pcount ) _cAtPut( _lbase + 14,  index, _lbase + 28 );
  _cAt( _lbase + 14, index, 0xFFFF, _eval );
}

CLIPPER _DATA1()  { _SetGet(  1 ); }
CLIPPER _DATA2()  { _SetGet(  2 ); }
CLIPPER _DATA3()  { _SetGet(  3 ); }
CLIPPER _DATA4()  { _SetGet(  4 ); }
CLIPPER _DATA5()  { _SetGet(  5 ); }
CLIPPER _DATA6()  { _SetGet(  6 ); }
CLIPPER _DATA7()  { _SetGet(  7 ); }
CLIPPER _DATA8()  { _SetGet(  8 ); }
CLIPPER _DATA9()  { _SetGet(  9 ); }
CLIPPER _DATA10() { _SetGet( 10 ); }
CLIPPER _DATA11() { _SetGet( 11 ); }
CLIPPER _DATA12() { _SetGet( 12 ); }
CLIPPER _DATA13() { _SetGet( 13 ); }
CLIPPER _DATA14() { _SetGet( 14 ); }
CLIPPER _DATA15() { _SetGet( 15 ); }
CLIPPER _DATA16() { _SetGet( 16 ); }
CLIPPER _DATA17() { _SetGet( 17 ); }
CLIPPER _DATA18() { _SetGet( 18 ); }
CLIPPER _DATA19() { _SetGet( 19 ); }
CLIPPER _DATA20() { _SetGet( 20 ); }
CLIPPER _DATA21() { _SetGet( 21 ); }
CLIPPER _DATA22() { _SetGet( 22 ); }
CLIPPER _DATA23() { _SetGet( 23 ); }
CLIPPER _DATA24() { _SetGet( 24 ); }
CLIPPER _DATA25() { _SetGet( 25 ); }
CLIPPER _DATA26() { _SetGet( 26 ); }
CLIPPER _DATA27() { _SetGet( 27 ); }
CLIPPER _DATA28() { _SetGet( 28 ); }
CLIPPER _DATA29() { _SetGet( 29 ); }
CLIPPER _DATA30() { _SetGet( 30 ); }
CLIPPER _DATA31() { _SetGet( 31 ); }
CLIPPER _DATA32() { _SetGet( 32 ); }
CLIPPER _DATA33() { _SetGet( 33 ); }
CLIPPER _DATA34() { _SetGet( 34 ); }
CLIPPER _DATA35() { _SetGet( 35 ); }
CLIPPER _DATA36() { _SetGet( 36 ); }
CLIPPER _DATA37() { _SetGet( 37 ); }
CLIPPER _DATA38() { _SetGet( 38 ); }
CLIPPER _DATA39() { _SetGet( 39 ); }
CLIPPER _DATA40() { _SetGet( 40 ); }
CLIPPER _DATA41() { _SetGet( 41 ); }
CLIPPER _DATA42() { _SetGet( 42 ); }
CLIPPER _DATA43() { _SetGet( 43 ); }
CLIPPER _DATA44() { _SetGet( 44 ); }
CLIPPER _DATA45() { _SetGet( 45 ); }
CLIPPER _DATA46() { _SetGet( 46 ); }
CLIPPER _DATA47() { _SetGet( 47 ); }
CLIPPER _DATA48() { _SetGet( 48 ); }
CLIPPER _DATA49() { _SetGet( 49 ); }
CLIPPER _DATA50() { _SetGet( 50 ); }
CLIPPER _DATA51() { _SetGet( 51 ); }
CLIPPER _DATA52() { _SetGet( 52 ); }
CLIPPER _DATA53() { _SetGet( 53 ); }
CLIPPER _DATA54() { _SetGet( 54 ); }
CLIPPER _DATA55() { _SetGet( 55 ); }
CLIPPER _DATA56() { _SetGet( 56 ); }
CLIPPER _DATA57() { _SetGet( 57 ); }
CLIPPER _DATA58() { _SetGet( 58 ); }
CLIPPER _DATA59() { _SetGet( 59 ); }
CLIPPER _DATA60() { _SetGet( 60 ); }


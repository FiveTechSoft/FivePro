#include <extend.h>

CLIPPER HardCopy() { asm int 5; }

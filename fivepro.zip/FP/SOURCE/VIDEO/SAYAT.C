#include <ClipApi.h>

CLIPPER SayAt()
{
   _gtWriteAt( _parni( 1 ), _parni( 2 ), _parc( 3 ), _parclen( 3 ) );
}

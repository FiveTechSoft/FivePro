#include "extend.h"

CLIPPER nMemory()
{
   asm int 0x12;
   _retni( _AX );
}

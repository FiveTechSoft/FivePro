// Modulo de FivePro 1.0 pasado a modo protegido

#include "c:\blinker\c\blx286.h"
#include <extend.h>

//----------------------------------------------------------------------------//

CLIPPER InitVideo()
{
   USHORT wSel;

   DosMapRealSeg( 0xB800, 0xFFFF, &wSel );
}

//----------------------------------------------------------------------------//

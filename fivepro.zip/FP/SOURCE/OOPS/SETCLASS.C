#include <ClipApi.h>

CLIPPER SetClass()
{
   _VSetDict( _lbase + 2, _parni( 2 ) );
}

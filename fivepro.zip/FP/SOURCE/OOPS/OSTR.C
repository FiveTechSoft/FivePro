typedef struct
{
   BYTE bType;
   WORD wLen;


#include <dos.h>
#include "extend.h"

CLIPPER lKeyShiftL()
{
   _retl( peekb( 0, 0x417 ) & 2 );
}

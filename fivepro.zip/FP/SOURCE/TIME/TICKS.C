#include <extend.h>
#include <dos.h>

CLIPPER nTicks()
{
   _retnl( * ( ( unsigned long * )( MK_FP( 0, 0x46C ) ) ) );
}

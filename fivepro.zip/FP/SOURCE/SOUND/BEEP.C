// Makes a beep!

#include "ClipApi.h"

CLIPPER BEEP()
{
   _beep_();               // Terminal beep module <g>
}
